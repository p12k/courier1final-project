package com.example.courier1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.example.courier1.Couriers.dao.AdminDao;
import com.example.courier1.bean.*;

@Service
public class AdminServiceImpl implements AdminService{
	
	@Autowired
	private AdminDao dao;

	@Override
	public Boolean getAdmin(Admin admin) {
		System.out.println("before find all");
		List<Admin> adminList =(List<Admin>) dao.findAll();
		System.out.println(admin.username +" " +admin.password );
		boolean isPresent=false;
		
		for(int i=0;i<adminList.size();i++) {
			if((admin.username).equals(adminList.get(i).username)){
				if((admin.password).equals(adminList.get(i).password)){
					isPresent=true;
					System.out.println("Hello"); 
				}
			}
		}
		return isPresent;
	}

	@Override
	public Admin createAdmin(Admin admin) {
		
		return dao.save(admin);
		
	}
}

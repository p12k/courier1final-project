package com.example.courier1.service;

import java.util.List;

import com.example.courier1.bean.Couriers;
public interface CourierService {
	List<Couriers> getAllCourier();
	Couriers createCourier(Couriers courier);
	Couriers delete(Integer custId);
}

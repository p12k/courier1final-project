package com.example.courier1.Couriers.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.courier1.bean.Admin;



public interface AdminDao extends JpaRepository<Admin, Integer > {

}

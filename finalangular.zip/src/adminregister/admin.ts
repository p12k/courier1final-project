export class User{
    public username='';
    public password='';
}
export class User{
constructor(
public id ='',
public name ='',
public email ='',
public mobile=''
)

{}

}
   